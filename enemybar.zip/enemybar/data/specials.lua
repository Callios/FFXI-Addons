return {
	["Kei"]={
        ["Dancing Fullers"] = "Runaway 10+ yalme!",
	},
	["Ou"]={
        ["Dancing Fullers"] = "Runaway 10+ yalme!",
	},
	["Odin"]={
        ["Dread Spikes"] = "Dispel!",
		["Endark"] = "Dispel!",
	},
	["Glassy Craver"]={
        ["View Sync"] = "25 Yalme +",
	},
	["Glassy Thinker"]={
        ["Pain Sync"]= "No damage -> turnaround!"
    },
	--for testing pourposes
	["Obstreperous Panopt"]={
        ["Sylvan Slumber"] = "zZz long time!",
		["Crushing Gaze"] = "",
		["Retinal Glare"] = "",
	},
	["Ascended Panopt"]={
        ["Sylvan Slumber"] = "zZz long time!",
		["Crushing Gaze"] = "",
		["Retinal Glare"] = "",
	},
	["Indomitable Faaz"]={
        ["Sweeping Gouge"] = "",
		["Barreling Smash"] = "Smash that, give me some more!",
		["Zealous Snort"] = "",
	},
	["Ascended Faaz"]={
        ["Sweeping Gouge"] = "",
		["Barreling Smash"] = "Smash that, give me some more!",
		["Zealous Snort"] = "",
	},
	["Lady Lilith"]={
        ["Fatal Allure"] = "CHARM CHARM CHARM CHARM TURNAROUND",
		["Dark Thorn"] = "DREADSPIKES STOP THE HIT THINGS OH SHIT",
		["Subjugating Slash"] = "OH SHIT BIG DMG",
	},
	["Bozzetto Monarch"]={
        ["Lateral Reap"] = "TURNAROUND TRUN THE FUCK AROUND TURNAROUND",
        ["Lateral Slice"] = "TURNAROUND TRUN THE FUCK AROUND TURNAROUND",
        ["Lateral Slash"] = "TURNAROUND TRUN THE FUCK AROUND TURNAROUND",
		["Vertical Slice"] = "TURNAROUND TRUN THE FUCK AROUND TURNAROUND",
		["Vertical Slash"] = "TURNAROUND TRUN THE FUCK AROUND TURNAROUND",
		["Light of Condemnation"] = "SC STARTING SHIT SHIT FUCK",
	},
	["Tenzen"]={
        ["Yaegasumi"] = "YAG HE USED YAG YAG",
		["Meikyo Shisui"] = "DREADSPIKES STOP THE HIT THINGS OH SHIT",
		["Subjugating Slash"] = "OH SHIT BIG DMG",
	},
}