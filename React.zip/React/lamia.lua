return {
    ["Bozzetto Skathi"]={
        ["Blight Dance"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]="turnaround"
        }
    }, 
    ["Bozzetto Freyja"]={
        ["Petrifying Dance"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]="turnaround"
        }
    }, 
    ["Bozzetto Frigg"]={
        ["Raqs Baladi Dance"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]="turnaround"
        }
    }
}