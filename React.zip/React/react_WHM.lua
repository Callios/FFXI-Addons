return {
    ["Bozzetto Breadwinner"]={
        ["Fire Meeble Warble"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]='input /ma "Barfira" <me>'
        }, 
        ["Aero Meeble Warble"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]='input /ma "Baraera" <me>'
        }, 
        ["Water Meeble Warble"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]='input /ma "Barwatera" <me>'
        }, 
        ["Blizzard Meeble Warble"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]='input /ma "Barblizzara" <me>'
        }, 
        ["Stone Meeble Warble"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]='input /ma "Barstonra" <me>'
        }, 
        ["Thunder Meeble Warble"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]='input /ma "Barthundra" <me>'
        },
        ["Words of Bane"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]='input /ma "Barfira" <me>'
        }, 
        ["Sigh"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]='input /ma "Baraera" <me>'
        }, 
        ["Pierce Vitals"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]='input /ma "Barwatera" <me>'
        }, 
        ["Lateral Slash"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]='input /ma "Barblizzara" <me>'
        }, 
        ["Light of Pennance"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]='input /ma "Barstonra" <me>'
        }, 
        ["Vertical Slash"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]='input /ma "Barthundra" <me>'
        }
    }
}