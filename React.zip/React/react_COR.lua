return {
    ["Bozzetto Skathi"]={
        ["Blight Dance"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]="turnaround"
        }
    }, 
    ["Bozzetto Freyja"]={
        ["Petrifying Dance"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]="turnaround"
        }
    }, 
    ["Bozzetto Frigg"]={
        ["Raqs Baladi Dance"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]="turnaround"
        }
    },
    ["Lady Lilith"]={
        ["Dark Thorn"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]="turnaround"
        }
        },
        ["Lilith Ascendant"]={
        ["Dark Thorn"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]="turnaround"
        }
},
 ["Lady Lilith"]={
        ["Fatal Allure"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]="turnaround"
        }
        },
        ["Lilith Ascendant"]={
        ["Fatal Allure"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]="turnaround"
            }
            },
}
