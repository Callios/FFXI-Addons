return {
    ["Bozzetto Skathi"]={
        ["Blight Dance"]={
            ["complete_reaction"]="facemob", 
            ["ready_reaction"]="turnaround"
        },
        ["Petrifaction"]={
            ["complete_reaction"]="facemob", 
            ["ready_reaction"]="turnaround"
        },
        ["Imperiling Disregard"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]="facemob"
        }
    }, 
    ["Bozzetto Freyja"]={
        ["Petrifying Dance"]={
            ["complete_reaction"]="facemob", 
            ["ready_reaction"]="turnaround"
        },
        ["Petrifaction"]={
            ["complete_reaction"]="facemob", 
            ["ready_reaction"]="turnaround"
        },
        ["Imperiling Disregard"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]="facemob"
        }
    }, 
    ["Bozzetto Frigg"]={
        ["Raqs Baladi Dance"]={
            ["complete_reaction"]="facemob", 
            ["ready_reaction"]="turnaround"
        },
        ["Petrifaction"]={
            ["complete_reaction"]="facemob", 
            ["ready_reaction"]="turnaround"
        },
        ["Imperiling Disregard"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]="facemob"
        },
    },
    ["Lady Lilith"]={
        ["Fatal Allure"]={
            ["complete_reaction"]="facemob", 
            ["ready_reaction"]="turnaround"
    },
}
}