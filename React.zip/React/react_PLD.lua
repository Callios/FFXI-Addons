return {
    ["Bozzetto Retributionist"]={
        ["Nether Castigation"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]='input /p "OK TO GO"!'
        }
    }, 
    ["Bozzetto Retributionist"]={
        ["he boss's rage is beginning to boil over."]={
            ["complete_reaction"]="", 
            ["ready_reaction"]="turnaround"
        }
    }, 
    ["Bozzetto Retributionist"]={
        ["The boss's miasma dissipates, but its rage is beginning to boil over."]={
            ["complete_reaction"]="", 
            ["ready_reaction"]="turnaround"
        }
    },
    ["Lady Lilith"]={
        ["Fatal Allure"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]="turnaround"
        }
        },
        ["Lilith Ascendant"]={
        ["Fatal Allure"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]="turnaround"
        }
},
 ["Lady Lilith"]={
        ["Dark Thorn"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]="turnaround"
        }
        },
["Lilith Ascendant"]={
        ["Dark Thorn"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]="turnaround"
        }
},
 ["Bozzetto Monarch"]={
        ["Lateral Reap"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]="turnaround"
        },
        ["Vertical Slice"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]="turnaround"
        }
    }
}

