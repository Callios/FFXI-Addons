return {
    ["Odin Prime"]={
        ["Zantetsuken Kai"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]='input /kneel <bt>'
        }, 
        ["Aero Meeble Warble"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]='input /ma "Baraera" <me>'
        }, 
        ["Water Meeble Warble"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]='input /ma "Barwatera" <me>'
        }, 
        ["Blizzard Meeble Warble"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]='input /ma "Barblizzara" <me>'
        }, 
        ["Stone Meeble Warble"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]='input /ma "Barstonra" <me>'
        }, 
        ["Thunder Meeble Warble"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]='input /ma "Barthundra" <me>'
        },
            ["Lady Lilith"]={
        ["Fatal Allure"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]="turnaround"
        }
        },
        ["Lilith Ascendant"]={
        ["Fatal Allure"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]="turnaround"
        }
        },
 ["Lady Lilith"]={
        ["Dark Thorn"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]="turnaround"
        }
        },
        ["Lilith Ascendant"]={
        ["Dark Thorn"]={
            ["complete_reaction"]="", 
            ["ready_reaction"]="turnaround"
        }
}

    }
}
