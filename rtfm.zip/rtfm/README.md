![Demonstration Screenshot](https://raw.githubusercontent.com/ria-leberu/rtfm/main/rtfm_sample1.PNG "Demo Screenshot 1")

FFXI Windower Addon

rtfm - Read The Freakin' Move

Detect, alert and list mob moves as they occur in-game.

Commands:

help - display help text

alpha - adjust opacity of the display

Alert sound (Error Wooden) taken from freesound.org
