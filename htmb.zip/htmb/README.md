Original HTMB by Ivaar: https://github.com/Ivaar/Windower-addons

- //htmb - When near one of the KI NPCs, it will buy the KI\'s you have set.
- //htmb {list/l} - Prints out the full list of KI\'s you can add to the buy list.
- //htmb {list/l} {buy/set} - Prints out your currently set buy list.
- //htmb {add/a} {#} - adds the given KI # to the buy list.
- //htmb {remove/r} {#} - removes the KI # from the buy list.
