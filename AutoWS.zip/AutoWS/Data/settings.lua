return {
    ["Callios"] = {
        ["NIN"] = {
            ["Katana"] = {
                ["hps"] = {
                    ["<"] = 99,
                    [">"] = 1
                },
                ["mobs"] = {},
                ["ws_cmd"] = "/ws \"Blade: Ei\" <t>"
            }
        },
        ["RDM"] = {
            ["Sword"] = {
                ["hps"] = {
                    ["<"] = 100,
                    [">"] = 1
                },
                ["mobs"] = {},
                ["ws_cmd"] = "/ws \"fast blade\" <t>"
            }
        },
        ["THF"] = {
            ["Dagger"] = {
                ["hps"] = {
                    ["<"] = 100,
                    [">"] = 1
                },
                ["mobs"] = {},
                ["ws_cmd"] = "/ws \"gust slash\" <t>"
            }
        },
        ["WHM"] = {
            ["Club"] = {
                ["hps"] = {
                    ["<"] = 99,
                    [">"] = 1
                },
                ["mobs"] = {},
                ["ws_cmd"] = "/ws \"mystic boon\" <t>"
            }
        }
    },
    ["Gimples"] = {
        ["COR"] = {
            ["Dagger"] = {
                ["hps"] = {
                    ["<"] = 100,
                    [">"] = 5
                },
                ["mobs"] = {},
                ["ws_cmd"] = "/ws \"last stand\" <t>"
            }
        }
    },
    ["Gipi"] = {
        ["COR"] = {
            ["Sword"] = {
                ["hps"] = {
                    ["<"] = 100,
                    [">"] = 5
                },
                ["mobs"] = {},
                ["ws_cmd"] = "/ws \"savage blade\" <t>"
            }
        }
    },
    ["hps"] = {
        ["<"] = 100,
        [">"] = 5
    }
}
