return {
    ["Clubfoot"] = {
        ["COR"] = {
            ["Sword"] = {
                ["hps"] = {
                    ["<"] = 99,
                    [">"] = 1
                },
                ["mobs"] = {},
                ["tpgt"] = {
                    ["tp"] = 999
                },
                ["ws_cmd"] = "/ws \"Savage Blade\" <t>"
            }
        },
        ["THF"] = {
            ["Dagger"] = {
                ["hps"] = {
                    ["<"] = 99,
                    [">"] = 1
                },
                ["mobs"] = {},
                ["tpgt"] = {
                    ["tp"] = 1999
                },
                ["ws_cmd"] = "/ws \"Evisceration\" <t>"
            }
        }
    },
    ["Icydeath"] = {
        ["DRK"] = {
            ["Great Sword"] = {
                ["hps"] = {
                    ["<"] = 100,
                    [">"] = 1
                },
                ["mobs"] = {},
                ["tpgt"] = {
                    ["tp"] = 999
                },
                ["ws_cmd"] = "/ws \"Scourge\" <t>"
            },
            ["Scythe"] = {
                ["hps"] = {
                    ["<"] = 100,
                    [">"] = 5
                },
                ["mobs"] = {},
                ["tpgt"] = {
                    ["tp"] = 999
                },
                ["ws_cmd"] = "/ws \"entropy\" <t>"
            }
        }
    },
    ["hps"] = {
        ["<"] = 100,
        [">"] = 5
    },
    ["tpgt"] = {
        ["tp"] = 999
    }
}